// Shapes from docs/sino/architecture.md ("The 3 interfaces"). Do not rename keys.

export type Lang = 'tl' | 'en' | 'both'
export type Scale = 0 | 1 | 2 // A, A+, A++
export type Screen = 'home' | 'family' | 'ask' | 'activity' | 'receipt' | 'knows' | 'record' | 'person' | 'add' | 'account'
export type MemberColor = 'green' | 'amber' | 'red'

// health event (plus the additive model / last_event_at fields)
export interface Health {
  whisper: boolean
  ollama: boolean
  server: boolean
  mic: boolean
  offline: boolean
  model?: string
  last_event_at?: string
}

// Questions file entry: {id, question, phrasings[], reply_audio, photo, speaker}
export interface Question {
  id: string
  question: string
  phrasings: string[]
  reply_audio: string
  photo: string
  speaker: string
}

// Any message from /ws. We only read the events the caregiver screen gets.
export interface HubEvent {
  event: string
  [key: string]: unknown
}

// One card on the caregiver phone, built from the events above.
export type EntryKind = 'urgent' | 'seen' | 'needs' | 'answered' | 'note'
export interface Entry {
  id: string
  kind: EntryKind
  transcript: string // Lola's exact words. Never translated.
  at: number // ms since epoch, when the phone got it (latest repeat)
  firstAt?: number // first time Lola said it (grouped yellow cards)
  count: number // ask_caregiver repeats of the same transcript
  replyId?: string // comfort: which reply played
  speaker?: string // comfort: whose voice played
  savedByYou?: boolean // a reply recorded on this phone
  label?: [string, string] // note: what Lola did, [Tagalog, English]
  preset?: string // note: which quick pick, e.g. 'ate'
}

export interface Person {
  name: string // as Lola says it, e.g. "Joy"
  color: MemberColor
  local?: boolean // added on this phone only (not on the hub yet)
}

// Ask Sino about Lola (T7). The caregiver socket sends ask_about_lola and gets about_lola back
// (architecture.md, "Ask Sino about Lola"). Answers are built from the log, never a diagnosis.
export type AskIntent = 'how' | 'saying' | 'where' | 'ate' | 'unknown'
export interface ChatMsg {
  id: string
  from: 'you' | 'sino'
  text: string
  at: number
  pending?: boolean
  error?: boolean
  source?: string // "rule" / "model" from the hub, "fake" on the fake feed
  latencyMs?: number
}
